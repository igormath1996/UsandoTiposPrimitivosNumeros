package com.mycompany.usandotiposprimitivosnumeros;

import java.util.Scanner;

public class UsandoTiposPrimitivosNumeros {

    public static void main(String[] args) {
        Scanner entradaDados = new Scanner(System.in);

        System.out.println("Digite seu nome");
        String dadoDigitado = entradaDados.nextLine();
        System.out.println("Aluno: " + dadoDigitado);

        //boolean num1 = true; // verdadeiro ou falso (true ou false)
        //String a = "String texto";
        //float num22 = 8.5f; 
        //System.out.println("ex Boolean: "+num1);
        //System.out.println("String Ex :"+a);
        //System.out.println("Float Ex: "+num22);
        //System.out.printf("Float Ex: %.2f ", num22);
        //System.out.println("Char Ex: "+m);
    }
}
